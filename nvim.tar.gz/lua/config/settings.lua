print("Olá, usuário! Seja bem-vindo ao Neovim!")
